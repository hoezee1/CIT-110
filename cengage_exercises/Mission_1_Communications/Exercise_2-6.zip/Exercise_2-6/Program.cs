﻿// *********************************************************************
// Application:		Program
// Author: 			Hoezee, Joseph D
// Description:		
//
// Date Created: 1/17/2020
// *********************************************************************
using System;

namespace Exercise_26
{
    class MainClass
    {

        public double calculate(double h, double m)
        {
            return 200 + (150 * h) + (m*2);
        }

        public static void Main(string[] args)
        {
            double cost = 0;
            MainClass MC = new MainClass();

            Console.Write("Input the number of hours>\n");
            double hours = Convert.ToDouble(Console.ReadLine());
            Console.Write("Input the number of miles>\n");
            double miles = Convert.ToDouble(Console.ReadLine());

            cost = MC.calculate(hours, miles);

            Console.WriteLine($"For a move taking {hours} hours and going {miles} miles the estimate is ${cost}");

        }
    }
}
