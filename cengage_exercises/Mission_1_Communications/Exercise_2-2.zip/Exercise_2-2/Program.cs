﻿// *********************************************************************
// Application:     Program
// Author:          Hoezee, Joseph D
// Description:     
//
// Date Created: 1/16/2020
// *********************************************************************
using System;

namespace Exercise_22
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Abusing how the regular expression was written. I'm having a really fun time with this ☺. -Fetch the pattern--->[const]<---Good boy!-.= 2✌54 ;

            float cm = (float)2.54;

            Console.Write("Input a value in inches:>\n");
            float inches = Convert.ToSingle(Console.ReadLine());
            cm = inches * cm;
            Console.WriteLine($"{inches} inches is {cm} centimeters.");
        }
    }
}
