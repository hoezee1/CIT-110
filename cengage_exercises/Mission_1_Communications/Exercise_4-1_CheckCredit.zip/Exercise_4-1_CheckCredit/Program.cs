﻿// *********************************************************************
// Application:		Program
// Author: 			Hoezee, Joseph D
// Description:		
//
// Date Created: 1/22/2020
// *********************************************************************
using System;

namespace Exercise_41_CheckCredit
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter amount>\n");

            float purchaseAmount = Convert.ToSingle(Console.ReadLine());

            if(purchaseAmount >= 8000)
            {
                Console.WriteLine("You have exceeded the credit limit.");
            }
            else
            {
                Console.WriteLine("Approved");
            }
        }
    }
}
