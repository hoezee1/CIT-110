﻿// *********************************************************************
// Application:        Program
// Author:             Hoezee, Joseph D
// Description:        
//
// Date Created: 1/16/2020
// *********************************************************************
using System;

namespace Exercise1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            for (int i = 0; i < 5; i++)
            {
                if (i == 2)
                {
                    Console.WriteLine("HHHHHHHHHHHH");
                }
                else
                {
                    Console.WriteLine("H          H");
                }
            }
        }
    }
}
