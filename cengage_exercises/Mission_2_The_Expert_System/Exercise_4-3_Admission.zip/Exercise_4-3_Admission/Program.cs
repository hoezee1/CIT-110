﻿// *********************************************************************
// Application:		Program
// Author: 			Hoezee, Joseph D
// Description:		
//
// Date Created: 1/23/2020
// *********************************************************************
using System;

namespace Exercise_43_Admission
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.Write("Input high school GPA:>\n");
            float GPA = Convert.ToSingle(Console.ReadLine());

            Console.Write("Input admission test score:>\n");
            float testScore = Convert.ToSingle(Console.ReadLine());

            if (GPA >= 3.0 && testScore >= 60)
            {
                Console.Write("Accept");
            }
            else if (GPA < 3.0 && testScore >= 80)
            {
                Console.Write("Accept");
            }
            else
            {
                Console.Write("Reject");
            }
        }
    }
}
