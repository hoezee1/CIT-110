﻿// *********************************************************************
// Application:		Program
// Author: 			Hoezee, Joseph D
// Description:		
//
// Date Created: 1/23/2020
// *********************************************************************
using System;

namespace Exercise_51_SumFiveInts
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int [] integerArray = new int[5];

            for (int i = 0; i < 5; i++)
            {
                Console.Write($"[{i}] Enter an integer>\n");
                integerArray[i] = Convert.ToInt16(Console.ReadLine());
            }

            int total = 0;
            foreach (int i in integerArray)
            {
                total = i + total;
            }

            Console.Write(total);
        }
    }
}
