﻿// *********************************************************************
// Application:		Program
// Author: 			Hoezee, Joseph D
// Description:		
//
// Date Created: 1/16/2020
// *********************************************************************
using System;

namespace Exercise_22
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            double cm;
            Console.Write("Input a value in inches:>\n");
            double inches = Convert.ToDouble(Console.ReadLine());
            cm = inches * 2.54;
            Console.WriteLine($"{inches} inches is {cm} centimeters.");
        }
    }
}
